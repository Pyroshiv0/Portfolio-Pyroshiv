package net.mcreator.justenoughtgadgets.procedures;

public class HugeBucketEmpProjectileHitsBlockProcedure {
	public static void execute() {
	}
}
