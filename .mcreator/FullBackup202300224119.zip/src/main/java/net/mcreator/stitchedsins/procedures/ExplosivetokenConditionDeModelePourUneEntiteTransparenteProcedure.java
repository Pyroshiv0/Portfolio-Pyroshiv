package net.mcreator.stitchedsins.procedures;

public class ExplosivetokenConditionDeModelePourUneEntiteTransparenteProcedure {
	public static boolean execute() {
		return true;
	}
}
