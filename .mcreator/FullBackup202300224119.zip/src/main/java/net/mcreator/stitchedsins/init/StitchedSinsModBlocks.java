
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stitchedsins.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.stitchedsins.block.SewingTableBlock;
import net.mcreator.stitchedsins.StitchedSinsMod;

public class StitchedSinsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, StitchedSinsMod.MODID);
	public static final RegistryObject<Block> SEWING_TABLE = REGISTRY.register("sewing_table", () -> new SewingTableBlock());
}
