
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stitchedsins.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class StitchedSinsModTabs {
	public static CreativeModeTab TAB_MOD_OBJECTS;

	public static void load() {
		TAB_MOD_OBJECTS = new CreativeModeTab("tabmod_objects") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(StitchedSinsModItems.ETHER_STRING.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
