
package net.mcreator.stitchedsins.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.stitchedsins.init.StitchedSinsModTabs;

public class BoneNeedleItem extends Item {
	public BoneNeedleItem() {
		super(new Item.Properties().tab(StitchedSinsModTabs.TAB_MOD_OBJECTS).durability(10).rarity(Rarity.COMMON));
	}

	@Override
	public boolean hasCraftingRemainingItem() {
		return true;
	}

	@Override
	public ItemStack getCraftingRemainingItem(ItemStack itemstack) {
		return new ItemStack(this);
	}

	@Override
	public boolean isRepairable(ItemStack itemstack) {
		return false;
	}
}
