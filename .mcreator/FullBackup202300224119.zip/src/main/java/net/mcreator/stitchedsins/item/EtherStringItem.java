
package net.mcreator.stitchedsins.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

import net.mcreator.stitchedsins.init.StitchedSinsModTabs;

public class EtherStringItem extends Item {
	public EtherStringItem() {
		super(new Item.Properties().tab(StitchedSinsModTabs.TAB_MOD_OBJECTS).stacksTo(64).rarity(Rarity.COMMON));
	}
}
